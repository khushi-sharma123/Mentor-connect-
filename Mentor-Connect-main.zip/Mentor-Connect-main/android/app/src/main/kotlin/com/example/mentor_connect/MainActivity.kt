package com.example.mentor_connect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
